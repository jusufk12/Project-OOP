#ifndef REQUESTS_H
#define REQUESTS_H


class Requests
{
    public:
        Requests();
        virtual ~Requests();

    protected:

    private:
};

#endif // REQUESTS_H
