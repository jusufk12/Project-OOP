#include <iostream>
#include <Ordination.h>
#include <Dentist.h>
#include <Patient.h>
#include <vector>

using namespace std;

int main()
{

    Ordination ord;
    ord.menu();

    return 0;
}
