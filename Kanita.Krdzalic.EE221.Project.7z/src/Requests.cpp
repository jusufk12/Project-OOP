#include "Requests.h"

Requests::Requests()
{
    //ctor
}

Requests::~Requests()
{
    //dtor
}
